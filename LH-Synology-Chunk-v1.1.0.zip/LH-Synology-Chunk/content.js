(() => {
 const defaults = {enabled:true,size:64,threshold:90,debug:false};
 function publish() { chrome.storage.local.get(defaults, c => document.dispatchEvent(new CustomEvent('lh-chunk-config',{detail:JSON.stringify({...c, threshold:90})}))); }
 publish();
 document.addEventListener('DOMContentLoaded',publish,{once:true});
 chrome.storage.onChanged.addListener(publish);
})();
