const defaults={enabled:true,size:64,threshold:90,debug:false};
const $=id=>document.getElementById(id);
chrome.storage.local.get(defaults,c=>{for(const k of ['enabled','debug']) $(k).checked=c[k];for(const k of ['size','threshold']) $(k).value=k==='threshold'?90:c[k];});
$('save').onclick=()=>{const c={enabled:$('enabled').checked,debug:$('debug').checked,size:Number($('size').value),threshold:90};if(!Number.isFinite(c.size)||c.size<1||c.size>99.9){ $('status').textContent='Nhập chunk từ 1–99,9 MB.';return;}chrome.storage.local.set(c,()=>{$('status').textContent=chrome.runtime.lastError?'Lỗi lưu cấu hình':'Đã lưu. Tải lại DSM nếu cần.';});};
