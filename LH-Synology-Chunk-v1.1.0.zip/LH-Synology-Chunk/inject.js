(() => {
  'use strict';
  const defaults = {enabled:true, size:64, threshold:90, debug:false};
  let config = {...defaults}, ready = false;
  const patched = new WeakSet();
  const states = new WeakMap();
  document.addEventListener('lh-chunk-config', e => {
    try {
      const c = JSON.parse(e.detail);
      if (typeof c.enabled !== 'boolean' || !Number.isFinite(c.size) || c.size < 1 || c.size > 99.9 || c.threshold !== 90) return;
      config = {...c}; ready = true;
    } catch (_) {}
  });
  function install() {
    const p = window.SYNO?.FileStation?.Uploader?.HTML5Uploader?.prototype;
    if (!p || patched.has(p)) return;
    const prepare = p.prepareStartFormdata, partial = p.onUploadPartailFile;
    if (typeof prepare !== 'function' || typeof partial !== 'function' || !prepare.toString().includes('chunkmode') || !partial.toString().includes('chunksize')) return;
    p.prepareStartFormdata = function(file, ...args) {
      if (!ready || !config.enabled || !this.opts || !file || !Number.isFinite(file.size) || file.size < config.threshold * 1e6) return prepare.call(this,file,...args);
      const oldMode = this.opts.chunkmode, oldSize = this.opts.chunksize;
      // Native caller reads chunksize immediately after prepare returns.
      this.opts.chunkmode = true; this.opts.chunksize = Math.round(config.size * 1e6);
      states.set(file, this.opts.chunksize);
      try {
        const result = prepare.call(this,file,...args);
        if (config.debug) console.info('[LH Chunk] file bytes:',file.size,'chunk bytes:',this.opts.chunksize);
        return result;
      } finally {
        const opts = this.opts;
        queueMicrotask(() => { opts.chunkmode = oldMode; opts.chunksize = oldSize; });
      }
    };
    p.onUploadPartailFile = function(form,file,...args) {
      const size = states.get(file);
      if (!size || !this.opts) return partial.call(this,form,file,...args);
      const old = this.opts.chunksize;
      this.opts.chunksize = size;
      try { return partial.call(this,form,file,...args); }
      finally { this.opts.chunksize = old; }
    };
    patched.add(p);
    document.documentElement?.setAttribute('data-lh-chunk','installed');
  }
  setInterval(install,250);
  install();
})();
